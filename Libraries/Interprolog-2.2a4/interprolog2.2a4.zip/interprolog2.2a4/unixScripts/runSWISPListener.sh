. unixVariables.sh
${JAVA_BIN}/java -classpath ${CLASSPATH}:../interprolog.jar com.declarativa.interprolog.gui.SWISubprocessEngineWindow $1 ${SWI_BIN_DIRECTORY}/pl
#For Mac version use /swipl rather than /pl
