cd ..
$1/xsb -e "compile('com/declarativa/interprolog/xsb/interprolog.P'), compile('com/declarativa/interprolog/gui/visualization.P'), compile('com/declarativa/interprolog/tests.P'), halt."
