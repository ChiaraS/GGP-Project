# Mac OS locations are typically different from Linux
# You might want to edit unixVariable.sh variables starting from these:
JAVA_BIN=/System/Library/Java/JavaVirtualMachines/1.6.0.jdk/Contents/Home/bin
XSB_BIN_DIRECTORY=/Users/mc/XSB335/config/i386-apple-darwin10.8.0/bin
#XSB_BIN_DIRECTORY=/Users/mc/XSB331/config/i386-apple-darwin10.7.0/bin
#XSB_BIN_DIRECTORY=/Users/mc/XSB/config/i386-apple-darwin9.6.0/bin
#XSB_BIN_DIRECTORY=/Users/mc/XSB/config/i386-apple-darwin9.6.0-mt/bin
SWI_BIN_DIRECTORY=/usr/local/lib/swipl-5.4.7/bin/powerpc-darwin6.6
YAP_BIN_DIRECTORY=/usr/local/bin
