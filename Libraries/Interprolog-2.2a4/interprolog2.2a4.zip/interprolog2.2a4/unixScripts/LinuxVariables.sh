# This is a typical environment for Linux, see elsewhere for Mac OS X
JAVA_BIN=/usr/java/j2sdk1.4.2_09/bin
XSB_BIN_DIRECTORY=/home/YOUR_NAME/XSB271/config/i686-pc-linux-gnu/bin
SWI_BIN_DIRECTORY=/usr/lib/pl-5.4.7/bin/i686-linux
YAP_BIN_DIRECTORY=/usr/bin
