. unixVariables.sh
${JAVA_BIN}/java -classpath ${CLASSPATH}:../interprolog.jar com.declarativa.interprolog.gui.YAPSubprocessEngineWindow $1 ${YAP_BIN_DIRECTORY}/yap
